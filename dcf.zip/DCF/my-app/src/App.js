import CouponManagement from "./components/CouponManagement"; // Updated import

function App() {
  return (
    <div>
      <CouponManagement /> {/* Updated component */}
    </div>
  );
}

export default App;
