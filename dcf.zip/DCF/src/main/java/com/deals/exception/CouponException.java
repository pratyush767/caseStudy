package com.deals.exception;

public class CouponException extends RuntimeException {
    public CouponException(String message) {
        super(message);
    }
}
